﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Test.Algorithm
{
    /// <summary>
    /// 随机数生成辅助类
    /// </summary>
    public class RandomHelper
    {
        /// <summary>
        /// 获取一批随机数
        /// </summary>
        /// <param name="count">数量</param>
        /// <param name="seed">随机数种子</param>
        /// <returns></returns>
        public static int[] GetRandomData(int count, int seed)
        {
            if (count == 0)
            {
                throw new Exception("参数错误！");
            }

            int[] result = new int[count];
            Random random = new Random(seed);

            for (int i = 0; i < count; i++)
            {
                result[i] = random.Next();
            }

            return result;
        }
    }
}
