﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Loncin.Test.Contract;
using System.ServiceModel;

namespace Loncin.Test.Service
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    public class CalcService : ICalcContract
    {
        public double Add(double a, double b)
        {
            return a + b;
        }
    }
}
