﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Loncin.Test.Service;

namespace Loncin.Test.ExeHost
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost host = new ServiceHost(typeof(CalcService)))
            {
                host.Opened += delegate 
                {
                    Console.WriteLine("服务已经启动！");
                };

                host.Open();

                Console.ReadKey();
            }
        }
    }
}
