﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest
{
    public enum PassengerType
    {
        /// <summary>
        /// 成人
        /// </summary>
        Adult,
        /// <summary>
        /// 儿童
        /// </summary>
        Child,
        /// <summary>
        /// 婴儿
        /// </summary>
        Baby
    }
}
