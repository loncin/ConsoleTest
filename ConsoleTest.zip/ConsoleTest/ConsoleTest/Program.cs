﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.DirectoryServices;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Better.Infrastructures.Log;
using Better517Na.Business.AutoTicketOut.ServiceHelper;
using Loncin.Test.Model;

namespace ConsoleTest
{
    class Program
    {
        private static object obj = new object();

        static void Main(string[] args)
        {
            TrackIdManager.GetInstance("LXTEST");

            #region NoteCode
            #region 数据库测试
            //string strConn = "server=192.168.1.61;charset=utf8;database=HotelCore110;charset=utf8;uid=betterdev;pwd=better2008";

            //MySqlConnection conn = new MySqlConnection(strConn);

            //try
            //{
            //    conn.Open();

            //    using (MySqlCommand cmd = new MySqlCommand("SELECT @HotelID:=(select max(HotelID) from HotelBase110001) as HotelID", conn))
            //    {
            //        MySqlParameter parameter = new MySqlParameter("@HotelID", MySqlDbType.VarChar);
            //        cmd.Parameters.Add(parameter);
            //        //using (MySqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
            //        //{
            //        //    bool hasRows = reader.HasRows;
            //        //}



            //        object result = cmd.ExecuteScalar();
            //    }
            //}
            //finally
            //{
            //    conn.Close();
            //}
            #endregion

            #region 运算符重载
            //Operator aa = new Operator { Height = 20, Width = 10 };
            //Operator bb = new Operator { Height = 25, Width = 23 };
            //Operator cc = aa + bb;

            //Console.WriteLine(cc.Height);
            //Console.WriteLine(cc.Width);
            #endregion

            #region 委托测试
            //Action action1 = new Action(DelegateTest.ActionTest);
            //action1();

            //Action<string> action = new Action<string>(DelegateTest.ActionTest);
            //action("hello");

            //Func<int, int, string> func = new Func<int, int, string>(DelegateTest.FuncTest);
            //string result = func(3,5);
            //Console.WriteLine(result);

            #endregion

            #region LINQ测试
            //List<int> arr = new List<int>() { 1, 2, 3, 4, 5, 6, 7 };
            //var result = arr.Where(a => { return a > 3; }).Sum();
            //var result2 = (from v in arr where v > 3 select v).Sum();
            //Console.WriteLine(result);
            //Console.WriteLine(result2);

            #endregion

            #region JOIN测试

            //Person per1 = new Person { Name = "Jack", Age = 411, Id = "2023" };
            //Person per2 = new Person { Name = "Tom", Age = 56, Id = "2064" };
            //Person per3 = new Person { Name = "Jack", Age = 411, Id = "2023" };

            //List<Person> p1 = new List<Person> { per1, per2, per3 };

            //Person per4 = new Person { Name = "Bush", Age = 12, Id = "2012" };
            //Person per5 = new Person { Name = "Tom", Age = 32, Id = "2065" };
            //Person per6 = new Person { Name = "Obama", Age = 45, Id = "2024" };

            //List<Person> p2 = new List<Person> { per4, per5, per6 };

            //p1 = p1.Union(p2, new PersonCmopare()).ToList<Person>();

            #endregion

            #region SVN权限控制
            //for (int i = 0; i < 500; i++)
            //{
            //    Thread thread = new Thread(new ParameterizedThreadStart(SvnMultiple));
            //    thread.Start(i);
            //}

            //RecycleAuth(svnPath);
            #endregion

            #region 域用户测试

            //Console.WriteLine(DateTime.Now.ToString());

            ////IPHostEntry hostEntry = Dns.GetHostEntry("172.17.31.50");
            //Process p = new Process();
            //p.StartInfo.FileName = "cmd.exe";

            //p.StartInfo.UseShellExecute = false;
            //p.StartInfo.RedirectStandardInput = true;
            //p.StartInfo.RedirectStandardOutput = true;
            //p.StartInfo.CreateNoWindow = true;

            //p.Start();
            //p.StandardInput.WriteLine("nbtstat -A 172.17.31.64");

            //p.StandardInput.WriteLine("exit");
            //p.WaitForExit();
            //string cmdResult = p.StandardOutput.ReadToEnd();
            //p.Close();

            //Match mat = Regex.Match(cmdResult, @"\s+(?<MachineName>([0-9A-Za-z]|\-)+)\s*\<00\>\s+唯一.*");
            //string hostName = string.Empty;
            //if (mat.Success)
            //{
            //    hostName = mat.Groups["MachineName"].Value;
            //}

            //Console.WriteLine("DNS获取IP！" + DateTime.Now.ToString());
            ////if (hostEntry != null)
            ////{
            //using (var root = new DirectoryEntry())
            //{
            //    root.Path = "LDAP://517na.com";
            //    using (var searcher = new DirectorySearcher())
            //    {
            //        //string hostName = hostEntry.HostName.Split('.')[0];
            //        searcher.Filter = string.Format("(&(objectClass=user)(userworkstations=*{0}*))", hostName);
            //        searcher.PageSize = 256;
            //        searcher.SearchScope = SearchScope.Subtree;

            //        searcher.PropertiesToLoad.Add("cn");

            //        SearchResult result = searcher.FindOne();

            //        StringBuilder sb = new StringBuilder();
            //        if (result != null)
            //        {
            //            foreach (string name in result.Properties.PropertyNames)
            //            {
            //                sb.AppendFormat("{0}:", name);
            //                Console.WriteLine("{0}:", name);
            //                if (name == "objectsid")
            //                {
            //                    SecurityIdentifier identifier = new SecurityIdentifier(result.Properties[name][0] as Byte[], 0);

            //                    string SId = identifier.ToString();
            //                    Console.WriteLine("objectguid");
            //                }

            //                for (int i = 0; i < result.Properties[name].Count; i++)
            //                {
            //                    sb.AppendFormat("{0}", result.Properties[name][i]);
            //                    Console.WriteLine("{0}", result.Properties[name][i]);
            //                }

            //                sb.AppendLine();
            //                Console.WriteLine();
            //            }

            //            string str = sb.ToString();
            //        }
            //    }
            //    //}
            //}

            //using (var root = new DirectoryEntry())
            //{
            //    root.Path = "LDAP://517na.com";
            //    //root.Path = "LDAP://517NA.COM/CN=CP,OU=用户小组,DC=517NA,DC=COM";

            //    using (var searcher = new DirectorySearcher())
            //    {
            //        searcher.SearchRoot = root;
            //        System.Net.IPAddress adress = new System.Net.IPAddress(52);
            //        //IPHostEntry hostEntry = Dns.GetHostEntry("172.17.31.136");
            //        //IPHostEntry ddd = Dns.GetHostEntry("172.17.31.38");
            //        string strFilter = string.Format("(&(objectCategory=person)(objectClass=user)(SAMAccountName={0}))", "wangkun");
            //        searcher.Filter = strFilter;

            //        searcher.PageSize = 256;
            //        searcher.SearchScope = SearchScope.Subtree;

            //        //searcher.PropertiesToLoad.Add("cn");
            //        //searcher.PropertiesToLoad.Add("path");
            //        //searcher.PropertiesToLoad.Add("department");
            //        //searcher.PropertiesToLoad.Add("mail");
            //        //searcher.PropertiesToLoad.Add("mobile");
            //        //searcher.PropertiesToLoad.Add("displayname");
            //        //searcher.PropertiesToLoad.Add("ip");

            //        SearchResult result = searcher.FindOne();
            //        //SearchResultCollection results = searcher.FindAll();

            //        if (result != null)
            //        {
            //            //MUserInfo userInfo = new MUserInfo();

            //            //userInfo.UserID = GetProperty(result, "cn");
            //            //userInfo.UserName = GetProperty(result, "displayname");
            //            //userInfo.Mail = GetProperty(result, "mail");
            //            //userInfo.Mobile = GetProperty(result, "mobile");
            //            //userInfo.DeptName = GetProperty(result, "department");
            //            //userInfo.Path = GetProperty(result, "path");
            //            //userInfo.IsLeaf = true;

            //            StringBuilder sb = new StringBuilder();
            //            ResultPropertyCollection resultPropColl = result.Properties;
            //            string temp = GetProperty(result, "directreports");
            //            foreach (string name in result.Properties.PropertyNames)
            //            {
            //                sb.AppendFormat("{0}:", name);
            //                Console.WriteLine("{0}:", name);
            //                if (name == "objectsid")
            //                {
            //                    SecurityIdentifier identifier = new SecurityIdentifier(result.Properties[name][0] as Byte[], 0);

            //                    string SId = identifier.ToString();
            //                    Console.WriteLine("objectguid");
            //                }

            //                for (int i = 0; i < result.Properties[name].Count; i++)
            //                {
            //                    sb.AppendFormat("{0}", result.Properties[name][i]);
            //                    Console.WriteLine("{0}", result.Properties[name][i]);
            //                }

            //                sb.AppendLine();
            //                Console.WriteLine();
            //            }

            //            string str = sb.ToString();
            //        }
            //    }
            //}

            //ManagementObjectCollection instances = new ManagementClass("Win32_NetworkAdapterConfiguration").GetInstances();
            //foreach (ManagementObject mo in instances)
            //{
            //    if (mo["IPEnabled"].ToString() == "True")
            //    {
            //        string ttt = mo["MacAddress"].ToString();
            //        return;
            //    }
            //}
            #endregion

            #region XPATH测试
            //TrackID trackID = new TrackID("dd");
            //DomainAuthorizeHelper helper = new DomainAuthorizeHelper();
            //string xml = helper.GetLoveKaoTreeXML(trackID);

            //string str = null;
            //string str2 = "dfdf";
            //if (str2.IndexOf(str) > -1)
            //{
            //    Console.WriteLine("空也是一种包含");
            //}
            //List<string> lstStr = new List<string>();
            //lstStr.ForEach(p => Console.WriteLine(p));

            //int upCount = 0;
            //try
            //{
            //    upCount = 1;
            //    throw new Exception("dfd");
            //}
            //catch (Exception ex)
            //{ 

            //}
            #endregion

            #region UnityContainer测试
            //TrackIdManager.GetInstance("pt");
            //for (int i = 0; i < 500; i++)
            //{
            //    Thread thread = new Thread(new ParameterizedThreadStart(UnityContainerTest));
            //    thread.Start(i);
            //}
            #endregion

            #region 线程IsAlive
            //Thread thread = new Thread(new ThreadStart(ThreadAlive));
            //thread.IsBackground = true;
            //Console.WriteLine("start之前，isAlive:" + thread.IsAlive);
            //thread.Start();
            //Console.WriteLine("start之后，isAlive:" + thread.IsAlive);
            //while (true)
            //{
            //    if (!thread.IsAlive)
            //    {
            //        Console.WriteLine("判断线程是否结束，isAlive:" + thread.IsAlive);
            //        break;
            //    }
            //}
            #endregion

            #region DNS测试
            //System.Net.IPAddress[] address = Dns.GetHostAddresses("172.17.31.221");
            //foreach (System.Net.IPAddress add in address)
            //{
            //    Console.WriteLine(add);
            //}

            //IPHostEntry entry = Dns.GetHostEntry("172.17.31.136");
            //IPHostEntry entry2 = Dns.GetHostByAddress("172.17.31.221");

            //Console.WriteLine(entry.HostName);
            //Console.WriteLine(entry2.HostName);
            #endregion

            #region 多线程异常处理
            //try
            //{
            //    Thread thread = new Thread(ThreadAlive);
            //    thread.IsBackground = true;
            //    thread.Start();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            //decimal tt = Math.Round(0.014M, 2, MidpointRounding.AwayFromZero);
            #endregion

            #region 反射

            #endregion
            #endregion

            #region Others
            //UserRolenManager orgManager = new UserRolenManager();
            //orgManager.GetUserRole();

            //Aaa a = new Aaa();
            //Bbb b = new Bbb();
            //Console.WriteLine(a.PayAmount);
            //Console.WriteLine(b.PayAmount);

            //List<decimal> ddd = new List<decimal> { 25, 69, 14, 23 };

            //for (int i = 0; i < ddd.Count; i++)
            //{
            //    Console.WriteLine(ddd[i]);
            //}

            //Console.WriteLine();
            //ddd.Sort();
            //for (int i = 0; i < ddd.Count; i++)
            //{
            //    Console.WriteLine(ddd[i]);
            //}

            //OrderDetail detail = new OrderDetail { Status = "100", ErrorCode = "test", Result="dfsdd" };
            //detail.Express = new Express { ExpressAddress = "成都市金牛区", ExpressName = "顺风"};

            //XmlSerializer xmlSerial = new XmlSerializer(typeof(OrderDetail));
            //using (StringWriter sw = new StringWriter())
            //{
            //    xmlSerial.Serialize(sw, detail);
            //    string str = sw.ToString();
            //}

            //string str = string.Empty;
            //string[] str2 = str.Split('|');
            //string[] str3 = str2[0].Split('^');

            //string remark = "保险数量:20;保险单价:5;保险总金额:100";
            //int insuranceCount = 0; // 保险数量
            //if (!string.IsNullOrEmpty(remark))
            //{
            //    int.TryParse(remark.Substring(0, remark.IndexOf(";")).Replace("保险数量:", string.Empty), out insuranceCount);
            //}

            //string str = "^^";
            //string str2 = str.Replace("^", string.Empty);

            //string filePath = @"E:\ComptPrice\VTrunk\ComptPrice.sln";
            //string filePath = @"E:\PlamtSmallPro\branches\BackInvalidScanPro(20130712_0785)\Better.BackInvalidScanPro.Business\Better517Na.BackInvalidScanPro.Business.csproj";
            //Stopwatch stop = new Stopwatch();
            //stop.Start();

            //bool isSuccess = true;
            //ProgramCompile compile = new ProgramCompile();
            //try
            //{
            //    compile.RecurseCompile(filePath);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            //if (!isSuccess)
            //{
            //    Console.WriteLine(compile.CompileErrInfo);
            //}
            //else
            //{
            //    Console.WriteLine("编译成功");
            //}

            //stop.Stop();
            //Console.WriteLine("总共编译时间：{0}", stop.Elapsed.TotalMilliseconds);
            //Console.WriteLine();
            #endregion

            #region 杂项
            //AnanymousClass(new { id = "dfd", name = "jack" });

            //string url = "http://interface.jlfzg.com:90/commonQueryServlet";

            //string sendData = "{'Usercd':'CD19252','Authno':'123456', 'hotelIds':'1', 'roomtypeids':'','QueryType':'hotelpricecomfirm','checkInDate':'2013-11-22','checkOutDate':'2013-11-24'}";
            //////string sendData = "{'Usercd':'CD19252','Authno':'123456', 'hotelIds':'1/2/3/4/5/6/7/8/9/10', 'QueryType':'hotelinfo'}";
            //string result = InterfaceUtility.GetHttpRequestResult(url + "?" + sendData, 60000, SendMethod.POST, "utf-8");

            //JObject jobj = JObject.Parse(sendData);

            //Console.WriteLine(jobj["data"][0]["addresschn"]);


            //string filePath = @"E:\517Doc\99.员工活动\YF.20130706.Tiantai\byQingzhi\DSC_0008.jpg";
            //using (Bitmap map = new Bitmap(180, 119))
            //{
            //    using (Graphics g = Graphics.FromImage(map))
            //    {
            //        using (Image img = Image.FromFile(filePath))
            //        {
            //            //第二个参数；指定的是画布的宽度和高度(注意)
            //            g.DrawImage(img, new Rectangle(0, 0, map.Width, map.Height), new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);

            //            map.Save(@"E:\517Doc\99.员工活动\YF.20130706.Tiantai\Test\DSC_0008.jpg");//将缩略图保存到指定的文件夹中
            //        }
            //    }
            //}

            //DateTime initTime = DateTime.Now;
            //// 开始时间
            //DateTime startTime = initTime.AddMonths(2).AddDays(1 - initTime.Day);

            //// 结束时间
            //DateTime endTime = initTime.AddMonths(3).AddDays(-1);

            //TimeSpan ts = new TimeSpan(0, 70, 0);

            //HttpRuntime.Cache.Add("key", "value", null, Cache.NoAbsoluteExpiration, new TimeSpan(0, 0, 5), CacheItemPriority.NotRemovable, null);

            //Thread.Sleep(5000);
            ////HttpRuntime.Cache.Add("key1", "value1", null, Cache.NoAbsoluteExpiration, new TimeSpan(0, 30, 0), CacheItemPriority.NotRemovable, null);
            //Console.WriteLine(HttpRuntime.Cache["key"]);

            //string tick = "1235468794656";
            //string temp = tick.Insert(3,"-");

            //XingHaiBussiness xinhai = new XingHaiBussiness("72", "q_gczkku7fg7zphl");

            //XingHaiBussiness xinhai = new XingHaiBussiness("8848", "lph_fs9kjfhqonp7");

            //string reuslt = xinhai.GetHotelList(string.Empty);

            //StringBuilder sb = new StringBuilder();
            //MatchCollection matches = Regex.Matches(reuslt, "\"hotelid\":\\s\"(\\d{0,4})\"");
            //if (matches != null && matches.Count > 0)
            //{
            //    foreach (Match mat in matches)
            //    {
            //        sb.Append(mat.Groups[1].Value);
            //        sb.AppendLine();
            //    }
            //}

            //Console.WriteLine(sb.ToString());

            //string reuslt = xinhai.GetHotelPrice(2, string.Empty, "2013-11-06", "2013-11-07");
            //string reuslt2 = xinhai.GetHotelInfo(56);

            //string result3 = xinhai.GetHotelRoomState(2, "2288", "2013-11-06", "2013-11-07");
            //string url = "http://jdpay.517na.com/Jlnotify/Index?{'Usercd':'CD19252','Authno':'123456','roomtypeids':'15435}";
            //string result = InterfaceUtility.GetHttpRequestResult(url, 60000, SendMethod.POST, "utf-8");

            //int days = (int)3.6;

            //string dateFormat = string.Format("now:{0}", DateTime.Now);

            //string testStr = "dfdfd.csproj";
            //Console.WriteLine(testStr.Substring(testStr.LastIndexOf("/") + 1));

            //string user = "Agent1383805801";
            //string appKey = "af435da837f39dd4238828cdd3f38a55";
            //string secretKey = "1214b8e56619f447c9fdf21c177faf8e";

            //MHotelListPara listPara = new MHotelListPara();
            //listPara.ArrivalDate = "2013-12-03";
            //listPara.DepartureDate = "2013-12-04";
            //listPara.CityId = "0101";
            //listPara.CustomerType = "Prepay";
            //listPara.PageIndex = 0;
            //listPara.PageSize = 20;
            //ElongAccess elongAcc = new HotelListAccess(user, appKey, secretKey, listPara);
            //elongAcc.Execute();
            #endregion

            #region 生成唯一键
            //string hashCode = "1311121732099748069jd02001";
            //int intHasCode = hashCode.GetHashCode();

            //List<long> lstGuid = new List<long>();
            //for (int k = 0; k < 1000000; k++)
            //{
            //    byte[] guid = Guid.NewGuid().ToByteArray();
            //    long i = 1;
            //    foreach (byte b in guid)
            //    {
            //        i *= ((int)b + 1);
            //    }

            //    //string strGuid = string.Format("{0:x}", i - DateTime.Now.Ticks);

            //    long intGuid = Math.Abs(BitConverter.ToInt64(guid, 0));

            //    if (intGuid <= 9223372036854775807)
            //    {
            //        Console.WriteLine("GUID溢出");
            //    }

            //    if (lstGuid.Contains(intGuid))
            //    {
            //        Console.WriteLine("GUID重复");
            //    }

            //    lstGuid.Add(intGuid);
            //}

            #endregion

            #region 查找文本文件
            //FileSearch fileSearch = new FileSearch(@"C:\Users\denglongxing.517NA\Desktop\201401客户端\20140105", "140104120259140142");
            //List<string> resultFile = fileSearch.Search();

            //if (resultFile != null && resultFile.Count > 0)
            //{
            //    foreach (string str in resultFile)
            //    {
            //        Console.WriteLine(str);
            //    }
            //}
            #endregion

            #region Linq排序
            //while (true)
            //{
            //    for (int i = 0; i < 10000; i++)
            //    {
            //        DateTime tempNow = DateTime.Now;
            //        List<SortModel> tempModels = new List<SortModel> 
            //    { 
            //        new SortModel{ ID = "2", DtNow = tempNow },
            //        new SortModel{ ID = "1", DtNow = tempNow }
            //    };

            //        List<SortModel> sortModels = new List<SortModel> 
            //    { 
            //        new SortModel{ ID = "2", State = "正在打印" },
            //        new SortModel{ ID = "1", State = "正在打印" }
            //    };

            //        foreach (var model in sortModels)
            //        {
            //            SortModel temp = tempModels.Find(p => p.ID == model.ID);
            //            if (temp != null)
            //            {
            //                model.DtNow = temp.DtNow;
            //            }
            //        }

            //        var sortList = from n in sortModels
            //                       orderby n.DtNow, n.ID ascending
            //                       select n;

            //        sortModels = sortList.ToList<SortModel>();

            //        if (sortModels[0].ID != "1")
            //        {
            //            Console.WriteLine("排序出错了!");
            //        }
            //    }

            //    Console.WriteLine("执行完毕");
            //    Thread.Sleep(2000);
            //}

            //List<Person> persons = new List<Person> 
            //{
            //    new Person{id="1", Age=11, Name="jack1", BirthTime=DateTime.Now.AddYears(-18)},
            //    new Person{id="2", Age=10, Name="jack3", BirthTime=DateTime.Now.AddYears(-15)},
            //    new Person{id="3", Age=13, Name="jack4", BirthTime=DateTime.Now.AddYears(-20)},
            //    new Person{id="4", Age=12, Name="jack6", BirthTime=DateTime.Now.AddYears(-22)}
            //};

            //persons.Sort((Person x, Person y) =>
            //{
            //    return x.BirthTime.CompareTo(y.BirthTime);
            //});

            //Console.WriteLine("排序前:");
            //persons.ForEach(p =>
            //{
            //    Console.WriteLine("id:{0};age:{1};name:{2}", p.id, p.Age, p.Name);
            //});

            //persons.Sort((Person p1, Person p2) =>
            //{
            //    return p1.Age.CompareTo(p2.Age);
            //});

            //Console.WriteLine("age排序后:");
            //persons.ForEach(p =>
            //{
            //    Console.WriteLine("id:{0};age:{1};name:{2}", p.id, p.Age, p.Name);
            //});

            //persons.Sort((Person p1, Person p2) =>
            //{
            //    return p1.Name.CompareTo(p2.Name);
            //});

            //Console.WriteLine("name排序后:");
            //persons.ForEach(p =>
            //{
            //    Console.WriteLine("id:{0};age:{1};name:{2}", p.id, p.Age, p.Name);
            //});


            #endregion

            #region 缓存
            //for (int i = 0; i < 10; i++)
            //{
            //    //CacheTest cacheTest = new CacheTest();
            //    string result = CacheHelper.GetCacheData<string>(new Func<string, string>(CacheTest.GetMyData), "one", 5, "test");
            //    Console.WriteLine(result);

            //    Thread.Sleep(60010);
            //}
            #endregion

            #region 线程

            //int count = 20;
            //ManualResetEvent manualEvent = new ManualResetEvent(false);
            //AutoResetEvent[] autoEvents = new AutoResetEvent[count];
            //for (int i = 0; i < count; i++)
            //{
            //    autoEvents[i] = new AutoResetEvent(false);
            //}

            //ThreadPool.QueueUserWorkItem((obj) =>
            //{
            //    manualEvent.Set();
            //});

            //List<int> data = new List<int>();

            //Stopwatch stop = new Stopwatch();
            //stop.Start();
            //for (int i = 0; i < count; i++)
            //{
            //    //Thread thread = new Thread((obj) =>
            //    //{
            //    //    Console.WriteLine("线程内执行:" + obj);
            //    //    List<int> temp = new List<int> { 2 + i, 5 + i, 4 + i };
            //    //    data.AddRange(temp);
            //    //    Thread.Sleep(1000);
            //    //});
            //    //thread.Start("hello");
            //    //thread.Join();

            //    ThreadPool.QueueUserWorkItem((obj) =>
            //        {
            //            manualEvent.WaitOne();
            //            int index = Convert.ToInt32(obj);
            //            autoEvents[index].WaitOne();
            //            Console.WriteLine("线程内执行:" + obj);
            //            List<int> temp = new List<int> { 2 + index, 5 + index, 4 + index };
            //            data.AddRange(temp);
            //            Thread.Sleep(1000);

            //            autoEvents[index].Set();
            //        }, i);
            //}

            //WaitHandle.WaitAll(autoEvents);
            //manualEvent.Reset();

            //stop.Stop();
            //Console.WriteLine("线程执行时间:" + stop.Elapsed.TotalMilliseconds);
            ////Thread.Sleep(5000);
            //for (int i = 0; i < data.Count; i++)
            //{
            //    Console.WriteLine(data[i]);
            //}

            //Console.WriteLine("主线程");
            #endregion

            #region 弱引用测试
            //int size = 50;
            //WeakCache weakCache = new WeakCache(size);

            //GC.Collect(0);

            //Random rand = new Random();
            //string name = string.Empty;
            //for (int i = 0; i < size; i++)
            //{
            //    int index = rand.Next(weakCache.Count);
            //    name = weakCache[index].Name;
            //}

            //Console.WriteLine("数据重建比例为:{0:P2}%", weakCache.RegeneCount / (double)weakCache.Count);


            #endregion

            #region 对象转换
            //Stopwatch stop = new Stopwatch();
            //stop.Start();

            //MHotelOrderA hotelOrderA = new MHotelOrderA()
            //{
            //    OrderId = "201406052018123456",
            //    HotelID = "001",
            //    HotelName = "香格里拉酒店",
            //    TotalFee = 1000,
            //    YfMoney = 10M,
            //    Rooms = new List<MHotelRoomA>() { 
            //        new MHotelRoomA(){
            //            KyeID="201406052018123456001", RoomImdex=1, CheckInDate=DateTime.Now.AddDays(1)
            //        },
            //        new MHotelRoomA(){
            //            KyeID="201406052018123456002", RoomImdex=2, CheckInDate=DateTime.Now.AddDays(1)
            //        },
            //        new MHotelRoomA(){
            //            KyeID="201406052018123456003", RoomImdex=3, CheckInDate=DateTime.Now.AddDays(1)
            //        },
            //    }
            //};

            //MHotelOrderB hotelOrderB = ConvertHelper.ConvertObj<MHotelOrderB, MHotelOrderA>(hotelOrderA);
            #endregion

            List<MSerializer> models = new List<MSerializer> { 
                new MSerializer() { ID = "1584", Day = DateTime.Now },
                new MSerializer() { ID = "1526", Day = DateTime.Now }
            };

            JsonSerializer serializer = new JsonSerializer();

            string json = serializer.Serialize(models);

            models = serializer.Deserialize<List<MSerializer>>(json);

            Console.ReadKey();
        }

        private static void UnityContainerTest(object obj)
        {
            try
            {
                AutoTicketServiceHelper helper = new AutoTicketServiceHelper();
                string result = helper.UnityContainerTest("singleTest");
                Console.WriteLine(obj + ":" + result);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private static void SvnMultiple(object param)
        {
            lock (obj)
            {
                string svnPath = @"https://192.168.1.64:8443/svn/ComptPriceNew/branches/ComptPrice(20121220_200)";
                List<string> users = new List<string>();
                users.Add("t" + param.ToString() + "=rw");
                WriteAutu(svnPath, users);
            }
        }

        /// <summary>
        /// SVN写入授权
        /// </summary>
        /// <param name="authPath">授权地址</param>
        /// <param name="users">授权用户</param>
        private static void WriteAutu(string authPath, List<string> users)
        {
            string realPath = authPath.Substring(authPath.IndexOf("svn") + 4);
            realPath = realPath.Insert(realPath.IndexOf('/'), ":");
            realPath = "[" + realPath + "]";

            StringBuilder sb = new StringBuilder();
            string str;
            StreamReader reader = new StreamReader(@"F:\authz");
            bool isFind = false;
            while ((str = reader.ReadLine()) != null)
            {
                if (isFind)
                {
                    foreach (string user in users)
                    {
                        sb.AppendLine(user);
                    }

                    isFind = false;
                }

                sb.AppendLine(str);
                if (str == realPath)
                {
                    isFind = true;
                }
            }

            reader.Close();

            StreamWriter writer = new StreamWriter(@"F:\authz");
            writer.WriteLine(sb.ToString());
            writer.Flush();
            writer.Close();
        }

        /// <summary>
        /// SVN回收权限
        /// </summary>
        /// <param name="authPath"></param>
        /// <param name="users"></param>
        private static void RecycleAuth(string authPath)
        {
            string realPath = authPath.Substring(authPath.IndexOf("svn") + 4);
            realPath = realPath.Insert(realPath.IndexOf('/'), ":");
            realPath = "[" + realPath + "]";

            StringBuilder sb = new StringBuilder();
            string str;
            StreamReader reader = new StreamReader(@"F:\authz");
            bool isFind = false;
            while ((str = reader.ReadLine()) != null)
            {
                if (isFind && str.IndexOf("=") > -1)
                {
                    continue;
                }

                isFind = false;

                sb.AppendLine(str);
                if (str == realPath)
                {
                    isFind = true;
                }
            }

            reader.Close();

            StreamWriter writer = new StreamWriter(@"F:\authz");
            writer.WriteLine(sb.ToString());
            writer.Flush();
            writer.Close();
        }

        /// <summary>
        /// 获取指定属性名对应的值
        /// </summary>
        /// <param name="searchResult">域查询结果</param>
        /// <param name="propertyName">属性英文名称</param>
        /// <returns>属性值</returns>
        private static string GetProperty(SearchResult searchResult, string propertyName)
        {
            if (searchResult.Properties.Contains(propertyName))
            {
                return searchResult.Properties[propertyName][0].ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        private static void ThreadAlive()
        {
            //Thread.Sleep(1000);
            Console.WriteLine("我正在活动哦！");
            throw new Exception("我这里出错了");
        }

        /// <summary>
        /// 获取组用户
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static List<string> GetMember(string strMember)
        {
            MatchCollection matches = Regex.Matches(strMember, @"(CN=(?<g>(.*?)),)");
            List<string> members = null;
            if (matches.Count > 0)
            {
                members = new List<string>();
                foreach (Match match in matches)
                {
                    members.Add(match.Groups["g"].Value);
                }
            }

            return members;
        }

        private static void AnanymousClass(object obj)
        {
            foreach (PropertyDescriptor property in TypeDescriptor.GetProperties(obj))
            {
                Console.WriteLine(string.Format("{0}:{1}", property.Name, property.GetValue(obj)));
            }
        }
    }

    public enum EType
    {
        AA = 1,
        BB = 2,
        CC = 3
    }

    /// <summary>
    /// 重载运算符
    /// </summary>
    public class Operator
    {
        public int Height { get; set; }

        public int Width { get; set; }

        public static Operator operator +(Operator a, Operator b)
        {
            Operator c = new Operator();
            c.Height = a.Height + b.Height;
            c.Width = a.Width + b.Width;
            return c;
        }
    }

    /// <summary>
    /// 委托
    /// </summary>
    public class DelegateTest
    {
        public static void ActionTest()
        {
            Console.WriteLine("无参数");
        }

        public static void ActionTest(string word)
        {
            Console.WriteLine(word);
        }

        public static string FuncTest(int a, int b)
        {
            return (a + b).ToString();
        }

        public void OverrideTest(int a)
        {
            Console.WriteLine("int");
        }

        public void OverrideTest(object obj)
        {
            Console.WriteLine("object");
        }
    }

    public class Person
    {
        public string id { get; set; }

        [DisplayName]
        [Description("Name1")]
        public string Name { get; set; }

        public int Age { get; set; }

        public string Remark { get; set; }

        public DateTime BirthTime { get; set; }
    }

    public class PersonCmopare : IEqualityComparer<Person>
    {
        #region IEqualityComparer<Person> 成员

        public bool Equals(Person x, Person y)
        {
            if (x == null)
            {
                return y == null;
            }

            return x.id == y.id;
        }

        public int GetHashCode(Person obj)
        {
            if (obj == null)
            {
                return 0;
            }

            return obj.id.GetHashCode();
        }

        #endregion
    }

    /// <summary>
    /// 域用户类
    /// </summary>
    [Serializable]
    public class MUserInfo
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        private string userID;

        /// <summary>
        /// 用户中文名
        /// </summary>
        private string userName;

        /// <summary>
        /// 用户所属部门
        /// </summary>
        private string deptID;

        /// <summary>
        /// 用户所属部门
        /// </summary>
        private string deptName;

        /// <summary>
        /// Mail
        /// </summary>
        private string mail;

        /// <summary>
        /// 手机号码
        /// </summary>
        private string mobile;

        /// <summary>
        /// PATH
        /// </summary>
        private string path = string.Empty;

        /// <summary>
        /// 构造函数
        /// </summary>
        public MUserInfo()
        {
        }

        /// <summary>
        /// 用户ID
        /// </summary>
        public string UserID
        {
            get { return this.userID; }
            set { this.userID = value; }
        }

        /// <summary>
        /// 用户中文名
        /// </summary>
        public string UserName
        {
            get { return this.userName; }
            set { this.userName = value; }
        }

        /// <summary>
        /// 用户所属部门
        /// </summary>
        public string DeptID
        {
            get { return this.deptID; }
            set { this.deptID = value; }
        }

        /// <summary>
        /// 用户所属部门
        /// </summary>
        public string DeptName
        {
            get { return this.deptName; }
            set { this.deptName = value; }
        }

        /// <summary>
        /// Mail
        /// </summary>
        public string Mail
        {
            get { return this.mail; }
            set { this.mail = value; }
        }

        /// <summary>
        /// 手机号码
        /// </summary>
        public string Mobile
        {
            get { return this.mobile; }
            set { this.mobile = value; }
        }

        /// <summary>
        /// PATH
        /// </summary>
        public string Path
        {
            get { return this.path; }
            set { this.path = value; }
        }

        /// <summary>
        /// 是否是员工结点
        /// </summary>
        public bool IsLeaf
        {
            get;
            set;
        }
    }
}
