﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;

namespace ConsoleTest
{
    public class ProgramCompile
    {
        /// <summary>
        /// 已经编译过的文件
        /// </summary>
        public List<string> compiledFile;

        /// <summary>
        /// 编译信息
        /// </summary>
        public string CompileErrInfo { get; set; }

        /// <summary>
        /// MSBulid编译
        /// </summary>
        /// <param name="getInfo">路径信息</param>
        /// <returns>编译结果</returns>
        public static string RunMSBuild(string getInfo)
        {
            string result = string.Empty;
            Process p = new Process();
            ProcessStartInfo the_StartInfo = new ProcessStartInfo();
            the_StartInfo.FileName = "C:\\Windows\\Microsoft.NET\\Framework\\v3.5\\MSBuild.exe";//@"C:\Program Files (x86)\Microsoft Visual Studio 9.0\Common7\IDE\devenv.com";
            the_StartInfo.Arguments = getInfo;//@"E:\SVNCode\546\SuspendTicket\SuspendTicket.sln /build";
            the_StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            the_StartInfo.WorkingDirectory = "C:\\Windows\\Microsoft.NET\\Framework\\v3.5\\";//@"C:\Program Files (x86)\Microsoft Visual Studio 9.0\Common7\IDE\";
            p.StartInfo = the_StartInfo;
            p.StartInfo.UseShellExecute = false;        //关闭Shell的使用
            //p.StartInfo.RedirectStandardInput = true;   //重定向标准输入
            p.StartInfo.RedirectStandardOutput = true;  //重定向标准输出
            p.StartInfo.RedirectStandardError = true;   //重定向错误输出
            p.StartInfo.CreateNoWindow = true;          //设置不显示窗口
            p.Start();   //启动
            return p.StandardOutput.ReadToEnd();        //从输出流取得命令执行结果
        }

        /// <summary>
        /// 执行编译
        /// </summary>
        /// <param name="compilePath"></param>
        /// <returns></returns>
        public bool Compile(string compilePath, out string strWrong)
        {
            string strRegex = RunMSBuild(compilePath + " /P:Configuration=Debug");
            Match match = Regex.Match(strRegex, @"生成成功|Build succeeded", RegexOptions.IgnoreCase);

            Console.WriteLine(strRegex);
            if (match.Success)
            {
                strWrong = string.Empty;
                return true;
            }
            else
            {
                strWrong = strRegex;
                return false;
            }
        }

        /// <summary>
        /// 非递归编译
        /// </summary>
        /// <param name="cmpPath"></param>
        /// <returns></returns>
        public bool SingleCompile(string cmpPath)
        {
            if (compiledFile == null)
            {
                compiledFile = new List<string>();
            }

            // 如果编译过的就不编译了
            if (compiledFile.Find(p => p.Contains(cmpPath)) == null)
            {
                compiledFile.Add(cmpPath);

                // 如果有路径包含空格就不编译了，因为MSBUILD对路径有空格的也编译不过
                if (cmpPath.Contains(" "))
                {
                    return true;
                }

                string strWrong = string.Empty;
                bool result = this.Compile(cmpPath, out strWrong);
                if (!result)
                {
                    this.CompileErrInfo += strWrong;
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 递归编译
        /// </summary>
        /// <param name="cmpFilePath"></param>
        /// <returns></returns>
        public bool RecurseCompile(string recurFilePath)
        {
            MatchCollection matches = null;

            recurFilePath = recurFilePath.Replace("/", "\\"); // 先将左斜杠替换成右斜杠 

            string fileContent = string.Empty;
            using (StreamReader reader = new StreamReader(recurFilePath))
            {
                fileContent = reader.ReadToEnd();
            }

            if (recurFilePath.EndsWith(".sln"))
            {
                string patten = string.Format(@"Project\(.+\)\s=\s.+\,.*{0}(?<project>.+\.csproj){0},.+", "\"");
                matches = Regex.Matches(fileContent, patten);
            }
            else if (recurFilePath.EndsWith(".csproj"))
            {
                string patten = string.Format(@"\<ProjectReference\sInclude={0}(?<project>.+.csproj){0}\>", "\"");
                matches = Regex.Matches(fileContent, patten);
            }

            if (matches != null && matches.Count > 0)
            {
                foreach (Match match in matches)
                {
                    // 引用的项目
                    string referenceProj = match.Groups["project"].Value;

                    string basePath = recurFilePath;
                    string compilePath = string.Empty;

                    // 解决方案
                    if (recurFilePath.EndsWith(".sln"))
                    {
                        // referenceProj = WebBLLService\WebBLLService.csproj
                        // cmpFilePath = E:\517Plugin\CRM\V0801\ComptPrice.sln
                        basePath = basePath.Substring(0, basePath.LastIndexOf("\\"));
                        compilePath = basePath + "\\" + referenceProj;
                    }
                    else  // 项目头
                    {
                        // referenceProj = ..\..\Model\Model.csproj
                        // cmpFilePath = E:\517Plugin\CRM\V0801\WebBLLService\WebBLLService.csproj
                        basePath = recurFilePath;
                        int direcCount = referenceProj.Split('\\').Count(p => p == "..") + 1;
                        for (int i = 0; i < direcCount; i++)
                        {
                            basePath = basePath.Substring(0, basePath.LastIndexOf("\\"));
                        }

                        compilePath = basePath + "\\" + referenceProj.Replace("..\\", string.Empty);
                    }

                    this.RecurseCompile(compilePath);
                }
            }

            // 执行编译 如果编译失败则抛出异常，退出递归
            if (!this.SingleCompile(recurFilePath))
            {
                throw new Exception("编译失败!");
            }

            return true;
        }
    }
}
