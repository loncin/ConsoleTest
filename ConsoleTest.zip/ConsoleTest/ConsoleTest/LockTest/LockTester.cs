﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.LockTest
{
    public class LockTester
    {
        private object obj = new object();

        private int count = 0;

        public void Test()
        {
            if (count == 0)
            {
                lock (obj)
                {
                    if (count == 0)
                    {
                        count++;
                    }
                }
            }
        }
    }
}
