﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using Better.Model.Worder;

namespace ConsoleTest.TestClass
{
    /// <summary>
    /// 弱引用测试
    /// </summary>
    public class WeakCache
    {
        private IDictionary<int, WeakReference> cahce;

        int regeneCount = 0;

        public WeakCache(int count)
        {
            this.cahce = new Dictionary<int, WeakReference>();
            for (int i = 0; i < count; i++)
            {
                this.cahce.Add(i, new WeakReference(new WeakData(i), false));
            }
        }

        public int Count
        {
            get { return this.cahce.Count; }
        }

        public int RegeneCount
        {
            get { return this.regeneCount; }
        }

        public WeakData this[int index]
        {
            get
            {
                WeakData data = this.cahce[index].Target as WeakData;
                if (data == null)
                {
                    data = new WeakData(index);
                    this.cahce[index].Target = data;

                    this.regeneCount++;

                    Console.WriteLine("数据对象{0}重建", index);
                }

                return data;
            }
        }
    }

    /// <summary>
    /// 若引用测试数据对象
    /// </summary>
    public class WeakData
    {
        private byte[] data;

        private string name;

        public WeakData(int size)
        {
            this.data = new byte[size * 1024];
            this.name = size.ToString();
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }
    }
}
