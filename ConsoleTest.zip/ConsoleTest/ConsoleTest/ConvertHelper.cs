﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ConsoleTest
{
    /// <summary>
    /// 转换工具类
    /// </summary>
    public class ConvertHelper
    {
        /// <summary>
        /// 对象转换
        /// </summary>
        /// <typeparam name="T">目标对象类型</typeparam>
        /// <typeparam name="S">源对象类型</typeparam>
        /// <param name="source">源对象</param>
        /// <returns>目标对象</returns>
        public static T ConvertObj<T, S>(S source)
        {
            if (source == null)
            {
                throw new ArgumentException("源对象为空！");
            }

            Type sourceType = source.GetType();
            PropertyInfo[] sourceProperties = sourceType.GetProperties();

            T target = Activator.CreateInstance<T>();
            Type targetType = target.GetType();
            PropertyInfo[] targetProperties = targetType.GetProperties();

            for (int i = 0; i < targetProperties.Length; i++)
            {
                // 不支持索引属性
                if (targetProperties[i].Name.Equals("Item"))
                {
                    continue;
                }

                // 源属性和目标属性需要属性名称和类型完全匹配
                PropertyInfo sourceProperty = sourceProperties.FirstOrDefault<PropertyInfo>(
                    p => p.Name.ToLower().Equals(targetProperties[i].Name.ToLower()) &&
                    p.PropertyType.FullName.Equals(targetProperties[i].PropertyType.FullName));

                if (sourceProperty != null)
                {
                    // 源属性可读，目标属性可写
                    if (sourceProperty.CanRead && targetProperties[i].CanWrite)
                    {
                        object value = sourceProperty.GetValue(source, null);
                        targetProperties[i].SetValue(target, value, null);
                    }
                }
            }

            return target;
        }
    }
}
