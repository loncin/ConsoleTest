﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest
{
    public static class ObjectExtension
    {
        /// <summary>
        /// 获取指定位数小数的十进制数（进位非四舍五入）
        /// </summary>
        /// <param name="orgin">十进制数</param>
        /// <param name="digit">指定保留的小数位数</param>
        /// <returns></returns>
        public static decimal RoundCeiling(this decimal target, int digit)
        {
            decimal sp = Convert.ToDecimal(Math.Pow(10, digit));
            decimal result = Math.Truncate(target) + Math.Ceiling((target - Math.Truncate(target)) * sp) / sp;
            return result;
        }
    }
}
