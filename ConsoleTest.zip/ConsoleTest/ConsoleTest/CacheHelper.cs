﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Caching;
using System.Threading;
using System.Reflection;

namespace ConsoleTest
{
    public class CacheHelper
    {
        //public static TResult GetCacheData<TResult>(Func<TResult> func, string cacheKey, int cacheTime)
        //{
        //    if (HttpRuntime.Cache.Get(cacheKey) == null)
        //    {
        //        Console.WriteLine("未命中缓存");
        //        TResult result = func();

        //        HttpRuntime.Cache.Add(cacheKey, result, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(cacheTime), CacheItemPriority.NotRemovable, null);

        //        return result;
        //    }

        //    Console.WriteLine("命中缓存");
        //    return (TResult)HttpRuntime.Cache.Get(cacheKey);
        //}

        public static TResult GetCacheData<T1, T2, TResult>(Func<T1, T2, TResult> func, string cacheKey, int cacheTime, T1 para1, T2 para2)
        {
            if (HttpRuntime.Cache.Get(cacheKey) == null)
            {
                Console.WriteLine("未命中缓存");
                TResult result = func(para1, para2);

                HttpRuntime.Cache.Add(cacheKey, result, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(cacheTime), CacheItemPriority.NotRemovable, null);

                return result;
            }

            Console.WriteLine("命中缓存");

            return (TResult)HttpRuntime.Cache.Get(cacheKey);
        }

        /// <summary>
        /// 获取缓存对象
        /// </summary>
        /// <typeparam name="T">缓存实体对象</typeparam>
        /// <param name="dele">实体数据获取方法</param>
        /// <param name="cacheKey">缓存关键字</param>
        /// <param name="cacheDuration">缓存时间（分钟）</param>
        /// <param name="objs">实体数据获取参 </param>
        /// <returns>参数T</returns>
        public static T GetCacheData<T>(Delegate dele, string cacheKey, int cacheDuration, params object[] objs)
        {
            if (HttpRuntime.Cache.Get(cacheKey) == null)
            {
                string assemblyName = dele.Target.GetType().Assembly.FullName;
                string typeName = dele.Target.GetType().FullName;
                object instance = Assembly.Load(assemblyName).CreateInstance(typeName);

                MethodInfo methodInfo = dele.Method;

                T result = (T)methodInfo.Invoke(instance, objs);

                HttpRuntime.Cache.Add(cacheKey, result, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(cacheDuration), CacheItemPriority.NotRemovable, null);
            }

            return (T)HttpRuntime.Cache[cacheKey];
        }

    }

    public class CacheTest
    {
        public static string GetMyData(string type)
        {
            //for (int i = 0; i < 100; i++)
            //{
            //    Console.WriteLine("循环第" + i + "次");
            //    //Thread.Sleep(20);
            //}

            return "hello";
        }
    }
}
