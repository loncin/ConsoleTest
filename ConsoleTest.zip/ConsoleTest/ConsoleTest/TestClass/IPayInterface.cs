﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.TestClass
{
    public interface IPayInterface
    {
        decimal PayAmount { get; }
    }

    public class Aaa : IPayInterface
    {

        #region IPayInterface 成员

        public decimal PayAmount
        {
            get { return 1; }
        }

        #endregion
    }

    public class Bbb : IPayInterface
    {

        #region IPayInterface 成员

        public decimal PayAmount
        {
            get { return 2; }
        }

        #endregion
    }
}
