﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;

namespace ConsoleTest
{
    public class JsonSerializer
    {
        private readonly JsonSerializerSettings serializerSettings;

        public JsonSerializer()
        {
            serializerSettings = new JsonSerializerSettings
            {
                Converters = new List<JsonConverter>
                {
                    new IsoDateTimeConverter()
                    {
                        DateTimeFormat="yyyy-MM-dd HH:mm:ss"
                    }
                }
            };
        }

        public string Serialize(object obj)
        {
            return obj == null ? null : JsonConvert.SerializeObject(obj, serializerSettings);
        }

        public T Deserialize<T>(string value) where T : class
        {
            return JsonConvert.DeserializeObject<T>(value, serializerSettings);
        }
    }
}