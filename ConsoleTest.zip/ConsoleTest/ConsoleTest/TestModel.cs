﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace ConsoleTest
{
    [Serializable]
    public class OrderDetail
    {
        [XmlAttribute]
        public string Status { get; set; }

        [XmlAttribute]
        public string ErrorCode { get; set; }

        [XmlElement]
        public Express Express { get; set; }

        [XmlIgnore]
        public string Result { get; set; }
    }

    [Serializable]
    public class Express
    {
        public string ExpressName { get; set; }

        public string ExpressAddress { get; set; }
    }
}
