﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest
{
    public class GenericTest
    {
        /// <summary>
        /// 通知
        /// </summary>
        /// <param name="hello">hello</param>
        public static void SayHello(string hello)
        {
            Console.WriteLine("sync say hello");
        }

        /// <summary>
        /// 异步发通知
        /// </summary>
        /// <param name="hello">hello</param>
        public static void AsycSayHello(string hello)
        {
            Action<string> action = SayHello;

            action.BeginInvoke(hello, null, null);
        }
    }
}
