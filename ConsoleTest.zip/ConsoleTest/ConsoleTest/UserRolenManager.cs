﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Better.Infrastructures.Log;
using Better.InternalDomainService.Helper;
using System.Xml;
using System.Data;
using Better.Infrastructures.DBUtility;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace ConsoleTest
{
    /// <summary>
    /// 用户角色管理类
    /// </summary>
    public class UserRolenManager
    {
        /// <summary>
        /// 角色ID基数
        /// </summary>
        private int roleId;

        /// <summary>
        /// 用户角色
        /// </summary>
        public List<MUerRole> UserRoles
        {
            get;
            private set;
        }

        /// <summary>
        /// 获取角色级别
        /// </summary>
        /// <returns></returns>
        public List<MUerRole> GetUserRole()
        {
            UserRoles = new List<MUerRole>();
            TrackID trackId = new TrackID("OA8000");
            DomainAuthorizeHelper helper = new DomainAuthorizeHelper();
            string ladpTree = helper.GetADTreeXML(trackId);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(ladpTree);
            roleId = 0;
            for (int i = 0; i < xmlDoc.ChildNodes.Count; i++)
            {
                XmlNode node = xmlDoc.ChildNodes[i];
                this.GetChildRole(node, 1, "ROOT");
            }


            return UserRoles;
        }

        /// <summary>
        /// 获取角色内用户
        /// </summary>
        /// <param name="node">父节点</param>
        /// <param name="roleRank">角色级别</param>
        /// <param name="roleParentId">父角色ID</param>
        private void GetChildRole(XmlNode node, int roleRank, string roleParentId)
        {
            if (node.Name.Equals("department"))
            {
                roleId++;
                MUerRole organization = new MUerRole();
                organization.RoleRank = roleRank; //岗位级别
                organization.RoleParentId = roleParentId; //父角色ID
                organization.RoleId = roleId.ToString(); // 角色ID，自动生成
                organization.RoleName = node.Attributes["deptName"].Value; // 角色名称

                string staffIds = ";";
                for (int i = 0; i < node.ChildNodes.Count; i++)
                {
                    XmlNode nodeChild = node.ChildNodes[i];
                    if (nodeChild.Name.Equals("department"))
                    {
                        this.GetChildRole(nodeChild, roleRank++, organization.RoleId);
                    }
                    else if (nodeChild.Name.Equals("staff"))
                    {
                        staffIds += nodeChild.Attributes["staffID"].Value + ";"; // 这里需要读取数据库，获取用户ID
                    }
                }

                organization.UserIdList = staffIds; // 适用用户
                this.UserRoles.Add(organization);
            }
        }
    }

    /// <summary>
    /// 用户角色
    /// </summary>
    public class MUerRole
    {
        /// <summary>
        /// 角色ID
        /// </summary>
        public string RoleId { get; set; }

        /// <summary>
        /// 组织ID
        /// </summary>
        public string OrgId { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// 适用用户
        /// </summary>
        public string UserIdList { get; set; }

        /// <summary>
        /// 父角色ID
        /// </summary>
        public string RoleParentId { get; set; }

        /// <summary>
        /// 系统岗位标识
        /// </summary>
        public string DeptId { get; set; }

        /// <summary>
        /// 角色级别
        /// </summary>
        public int RoleRank { get; set; }
    }
}
