﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleTest
{
    public class FileSearch
    {
        /// <summary>
        /// 文件夹
        /// </summary>
        private string direcPath;

        /// <summary>
        /// 关键字
        /// </summary>
        private string keyWords;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="direcPath"></param>
        /// <param name="keyWords"></param>
        public FileSearch(string direcPath, string keyWords)
        {
            this.direcPath = direcPath;
            this.keyWords = keyWords;
        }

        /// <summary>
        /// 文件搜索
        /// </summary>
        /// <param name="direcPath"></param>
        /// <param name="keyWords"></param>
        /// <returns></returns>
        public List<string> Search()
        {
            if (!Directory.Exists(direcPath))
            {
                throw new Exception("文件目录不存在！");
            }

            List<string> resultPaths = new List<string>();
            DirectoryInfo direcInfo = new DirectoryInfo(this.direcPath);
            foreach (FileInfo fileInfo in direcInfo.GetFiles())
            {
                using (StreamReader reader = fileInfo.OpenText())
                {
                    string content = reader.ReadToEnd();
                    if (content.Contains(this.keyWords))
                    {
                        resultPaths.Add(fileInfo.FullName);
                    }
                }
            }

            return resultPaths;
        }
    }
}
