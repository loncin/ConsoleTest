﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceActive
{
    public class HotelListAccess : ElongAccess
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="user">账户名</param>
        /// <param name="appkey">api key</param>
        /// <param name="secrecKey">user key</param>
        public HotelListAccess(string user, string appkey, string secretKey, object busiObj)
            : base(user, appkey, secretKey, busiObj)
        {
            this.method = "hotel.list";
        }

        /// <summary>
        /// 生成业务参数
        /// </summary>
        /// <returns></returns>
        protected override string GetBusiPara()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this.BusiObj);
        }

        /// <summary>
        /// 解析结果
        /// </summary>
        /// <returns></returns>
        protected override object AnalyResult()
        {
            return null;
        }
    }
}
