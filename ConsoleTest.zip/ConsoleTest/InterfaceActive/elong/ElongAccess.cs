﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace InterfaceActive
{
    /// <summary>
    /// 艺龙接口访问基类
    /// </summary>
    public abstract class ElongAccess
    {
        #region 数据成员
        /// <summary>
        /// 数据格式
        /// </summary>
        private string format = "json";

        /// <summary>
        /// 账户名
        /// </summary>
        private string user;

        /// <summary>
        /// api key
        /// </summary>
        private string appkey;

        /// <summary>
        /// user key
        /// </summary>
        private string secretKey;

        /// <summary>
        /// 时间戳
        /// </summary>
        protected string timeStamp;

        /// <summary>
        /// 方法名
        /// </summary>
        protected string method;

        /// <summary>
        /// 请求地址
        /// </summary>
        public string RequestUrl
        {
            get { return "http://api.elong.com/rest"; }
        }

        /// <summary>
        /// 请求结果
        /// </summary>
        public string ResponseData
        {
            get;
            private set;
        }

        /// <summary>
        /// 业务参数对象
        /// </summary>
        public object BusiObj
        {
            get;
            protected set;
        }

        /// <summary>
        /// 返回对象
        /// </summary>
        public object Result
        {
            get;
            protected set;
        }
        #endregion

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="user">账户名</param>
        /// <param name="appkey">api key</param>
        /// <param name="secrecKey">user key</param>
        public ElongAccess(string user, string appkey, string secretKey, object busiObj)
        {
            this.user = user;
            this.appkey = appkey;
            this.secretKey = secretKey;
            this.BusiObj = busiObj;
        }

        /// <summary>
        /// 执行方法
        /// </summary>
        public void Execute()
        {
            this.timeStamp = GetUnixTimeStamp(DateTime.Now);
            // 获取请求字符串
            string reqUrl = this.GetRequestUrl();

            this.ResponseData = InterfaceUtility.GetHttpRequestResult(reqUrl, 60000, SendMethod.GET, "utf-8");

            this.Result = this.AnalyResult();
        }

        /// <summary>
        /// 获取请求字符串
        /// </summary>
        /// <returns></returns>
        public string GetRequestUrl()
        {
            StringBuilder sbUrl = new StringBuilder();

            // 业务参数
            string busiData = this.GetGeneralPara();
            sbUrl.Append(RequestUrl);
            sbUrl.Append("?");
            sbUrl.AppendFormat("user={0}", this.user);
            sbUrl.AppendFormat("&format={0}", this.format);
            sbUrl.AppendFormat("&method={0}", this.method);
            sbUrl.AppendFormat("&timestamp={0}", this.timeStamp);
            sbUrl.AppendFormat("&data={0}", HttpUtility.UrlEncode(busiData, Encoding.GetEncoding("utf-8")));
            sbUrl.AppendFormat("&signature={0}", this.GetMd5Data(busiData));

            return sbUrl.ToString();
        }

        /// <summary>
        /// 生成业务参数
        /// </summary>
        /// <returns></returns>
        protected abstract string GetBusiPara();


        /// <summary>
        /// 获取通用参数
        /// </summary>
        /// <returns></returns>
        protected string GetGeneralPara()
        {
            // 构造业务参数字符串
            string data = this.GetBusiPara();

            StringBuilder geneJson = new StringBuilder();
            geneJson.Append("{");
            geneJson.Append("\"Version\":\"1.02\",");
            geneJson.Append("\"Local\":\"zh_CN\",");
            geneJson.AppendFormat("\"Request\":{0}", data);
            geneJson.Append("}");

            return geneJson.ToString();
        }

        /// <summary>
        /// 解析结果
        /// </summary>
        /// <returns></returns>
        protected abstract object AnalyResult();

        /// <summary>
        /// 获取MD5加密数据
        /// </summary>
        /// <returns></returns>
        private string GetMd5Data(string busiData)
        {
            return InterfaceUtility.GetMD5(this.timeStamp + InterfaceUtility.GetMD5(busiData + this.appkey, "utf-8") + secretKey, "utf-8");
        }

        /// <summary>
        /// 时间转成Unix时间戳
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        private static string GetUnixTimeStamp(DateTime dateTime)
        {
            return ((dateTime.Ticks - DateTime.Parse("1970-01-01 00:00:00").Ticks) / 10000000).ToString();
        }
    }
}
