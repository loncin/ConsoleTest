﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceActive
{
    public class MPosition
    {
        /// <summary>
        /// 经度
        /// </summary>
        public string Longitude { get; set; }

        /// <summary>
        /// 纬度
        /// </summary>
        public string Latitude { get; set; }

        /// <summary>
        /// 半径
        /// </summary>
        public int Radius { get; set; }
    }
}
