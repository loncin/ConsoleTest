﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceActive
{
    public class MHotelListPara
    {
        /// <summary>
        /// 入住日期
        /// </summary>
        public string ArrivalDate { get; set; }

        /// <summary>
        /// 离店日期
        /// </summary>
        public string DepartureDate { get; set; }

        /// <summary>
        /// 城市编码
        /// </summary>
        public string CityId { get; set; }

        /// <summary>
        /// 查询文本
        /// </summary>
        public string QueryText { get; set; }

        /// <summary>
        /// 支付方式 All-全部 SelfPay-现付 Prepay-预付
        /// </summary>
        public string PaymentType { get; set; }

        /// <summary>
        /// 产品类型 All=全部 LastMinuteSale=今日特价 LimitedTimeSale=限时抢购  WithoutGuarantee=免担保
        /// </summary>
        public string ProductProperties { get; set; }

        /// <summary>
        /// 设施
        /// </summary>
        public string Facilities { get; set; }

        /// <summary>
        /// 星级
        /// </summary>
        public string StarRate { get; set; }

        /// <summary>
        /// 品牌编码
        /// </summary>
        public string BrandId { get; set; }

        /// <summary>
        /// 酒店集团编码
        /// </summary>
        public string GroupId { get; set; }

        /// <summary>
        /// 最小价格
        /// </summary>
        public decimal LowRate { get; set; }

        /// <summary>
        /// 最大价格
        /// </summary>
        public decimal HighRate { get; set; }

        /// <summary>
        /// 地区编码
        /// </summary>
        public string DistrictId { get; set; }

        /// <summary>
        /// 地标编码
        /// </summary>
        public string LocationId { get; set; }

        /// <summary>
        /// 位置信息
        /// </summary>
        public MPosition Position { get; set; }

        /// <summary>
        /// 排序类型 Default艺龙默认排序 StarRankDesc推荐星级降序 RateAsc价格升序 DistanceAsc距离升序
        /// </summary>
        public string Sort { get; set; }

        /// <summary>
        /// 页码 从0开始
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// 每页记录数
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// 宾客类型 All=统一价；Chinese=内宾价；OtherForeign=外宾价；HongKong=港澳台客人价；Japanese=日本客人价
        /// </summary>
        public string CustomerType { get; set; }

        /// <summary>
        /// 返回信息类型
        /// </summary>
        public string ResultType { get; set; }
    }
}
