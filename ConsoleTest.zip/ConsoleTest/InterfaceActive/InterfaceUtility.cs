﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Xml;
using System.Security.Cryptography;

namespace InterfaceActive
{
    /// <summary>
    /// 接口调用方式
    /// </summary>
    public enum SendMethod
    {
        GET,
        POST
    }

    public class InterfaceUtility
    {
        public static void AddParameter(StringBuilder paras, string paraName, string paraValue, bool isAddEmpt)
        {
            if (!isAddEmpt && !string.IsNullOrEmpty(paraValue))
            {
                paras.AppendFormat("{0}={1}&", paraName, paraValue);
            }
        }

        //功能函数。将变量值不为空的参数组成字符串（1：返回字符串，2：参数名,3：参数值）
        public static string appendParam(string returnStr, string paramId, string paramValue)
        {
            if (returnStr != "")
            {
                if (paramValue != "")
                {
                    returnStr += "&" + paramId + "=" + paramValue;
                }
            }
            else
            {
                if (paramValue != "")
                {
                    returnStr = paramId + "=" + paramValue;
                }
            }
            return returnStr;
        }

        public static void AddParameter(List<string> paras, string paraName, string paraValue)
        {
            if (!string.IsNullOrEmpty(paraValue))
            {
                paras.Add(string.Format("{0}={1}", paraName, paraValue));
            }
        }

        public static string GetTxtFromXml(XmlNode node, string xpath)
        {
            if (node.SelectSingleNode(xpath) == null)
            {
                return "";
            }
            else
            {
                return node.SelectSingleNode(xpath).InnerText.Replace("\t\t", "").Replace("\t", "").Replace("\r\n", "").Replace("\r\n", "");
            }
        }

        public static string GetTxtFromXml(XmlNode node, string xpath, int no)
        {
            if (node.SelectSingleNode(xpath) == null)
            {
                return "";
            }
            {
                return node.SelectNodes(xpath).Item(no).InnerText.Replace("\t\t", "").Replace("\t", "").Replace("\r\n", "").Replace("\r\n", "");
            }
        }

        /// <summary>
        /// 对参数进行URL Encoding编码
        /// </summary>
        /// <param name="argumentInfo"></param>
        /// <returns></returns>
        public static string ArgumentEncode(string argumentInfo, string inputCharset)
        {
            string encodedString = System.Web.HttpUtility.UrlEncode(argumentInfo, Encoding.GetEncoding(inputCharset));

            return encodedString;
        }

        /// <summary>
        /// 与ASP兼容的MD5加密算法
        /// </summary>
        public static string GetMD5(string inputString, string inputCharset)
        {
            System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] encryptedBytes = md5.ComputeHash(Encoding.GetEncoding(inputCharset).GetBytes(inputString));
            StringBuilder sb = new StringBuilder(32);

            for (int i = 0; i < encryptedBytes.Length; i++)
            {
                sb.Append(encryptedBytes[i].ToString("x").PadLeft(2, '0'));
            }

            return sb.ToString();
        }

        public static string GetEntMD5(string encypStr, string charset)
        {
            string retStr;
            MD5CryptoServiceProvider m5 = new MD5CryptoServiceProvider();

            //创建md5对象
            byte[] inputBye;
            byte[] outputBye;

            //使用GB2312编码方式把字符串转化为字节数组．
            try
            {
                inputBye = Encoding.GetEncoding(charset).GetBytes(encypStr);
            }
            catch
            {
                inputBye = Encoding.GetEncoding("GB2312").GetBytes(encypStr);
            }
            outputBye = m5.ComputeHash(inputBye);

            retStr = System.BitConverter.ToString(outputBye);
            retStr = retStr.Replace("-", "").ToUpper();

            return retStr;
        }

        /// <summary>
        /// 合并两个数组
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="array1"></param>
        /// <param name="array2"></param>
        /// <returns></returns>
        public static T[] CombinationArray<T>(IList<T> array1, IList<T> array2)
        {
            T[] array = new T[array1.Count + array2.Count];

            array1.CopyTo(array, 0);
            array2.CopyTo(array, array1.Count);

            return array;
        }

        //执行http调用
        public static string GetRequestResult(string requestUrl, int timeout, SendMethod requestMethod, string codeName, string certFile, string certPasswd)
        {
            StreamReader sr = null;
            HttpWebResponse wr = null;
            string strResult = null;
            HttpWebRequest hp = null;
            string postData = null;

            if (Enum.GetName(typeof(SendMethod), requestMethod).ToUpper() == "POST")
            {
                string[] sArray = System.Text.RegularExpressions.Regex.Split(requestUrl, "\\?");

                hp = (HttpWebRequest)WebRequest.Create(sArray[0]);

                if (sArray.Length >= 2)
                {
                    postData = sArray[1];
                }
            }
            else
            {
                hp = (HttpWebRequest)WebRequest.Create(requestUrl);
            }


            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback((a, b, c, d) => { return true; });
            if (certFile != "")
            {
                hp.ClientCertificates.Add(new X509Certificate2(certFile, certPasswd));
            }
            hp.Timeout = timeout;

            System.Text.Encoding encoding = System.Text.Encoding.GetEncoding(codeName);

            if (postData != null)
            {
                byte[] data = encoding.GetBytes(postData);
                hp.Method = "POST";
                //hp.ContentType = "application/x-www-form-urlencoded";
                hp.ContentType = "text/html;charset=utf-8";
                hp.ContentLength = data.Length;
                Stream ws = hp.GetRequestStream();

                // 发送数据
                ws.Write(data, 0, data.Length);
                ws.Close();
            }
            wr = (HttpWebResponse)hp.GetResponse();
            sr = new StreamReader(wr.GetResponseStream(), encoding);
            strResult = sr.ReadToEnd();
            sr.Close();
            wr.Close();
            hp.Abort();

            return strResult;
        }

        /// <summary>
        ///  对字符串进行URL解码
        /// </summary>
        public static string UrlDecode(string instr, string charset)
        {
            if (instr == null || instr.Trim() == "")
                return "";
            else
            {
                string res;

                try
                {
                    res = HttpUtility.UrlDecode(instr, Encoding.GetEncoding(charset));

                }
                catch
                {
                    res = HttpUtility.UrlDecode(instr, Encoding.GetEncoding("GB2312"));
                }

                return res;
            }
        }

        private static string GetRequestResult(string requestUrl, int timeout, SendMethod requestMethod, string codeName)
        {
            string strResult;

            HttpWebRequest hp = (HttpWebRequest)HttpWebRequest.Create(requestUrl);
            hp.Method = Enum.GetName(typeof(SendMethod), requestMethod);
            hp.ContentType = "application/x-www-form-urlencoded";
            hp.Timeout = timeout;

            HttpWebResponse HttpWResp = (HttpWebResponse)hp.GetResponse();
            Stream myStream = HttpWResp.GetResponseStream();
            StreamReader sr = new StreamReader(myStream, Encoding.GetEncoding(codeName));
            StringBuilder strBuilder = new StringBuilder();

            while (-1 != sr.Peek())
            {
                strBuilder.Append(sr.ReadLine());
            }
            strResult = strBuilder.ToString();

            //XMLHTTP xmlhttp = new XMLHTTP();
            //xmlhttp.open("GET", requestUrl, false, null, null);
            //xmlhttp.send("");
            //MSXML2.XMLDocument dom = new XMLDocument();
            //Byte[] b = (Byte[])xmlhttp.responseBody;
            //strResult = System.Text.Encoding.GetEncoding("GB2312").GetString(b).Trim();

            return strResult;
        }

        /// <summary>
        /// 发送 HTTP 请求，并返回请求结果
        /// </summary>
        /// <param name="requestUrl">请求URL地址</param>
        /// <param name="timeout">请求超时时间</param>
        /// <param name="requestMethod">请求方法</param>
        /// <returns>请求结果</returns>
        public static string GetHttpRequestResult(string requestUrl, int timeout, SendMethod requestMethod)
        {
            return GetRequestResult(requestUrl, timeout, requestMethod, "gb2312", "", "");
        }

        /// <summary>
        /// 发送 HTTP 请求，并返回请求结果
        /// </summary>
        /// <param name="requestUrl">请求URL地址</param>
        /// <param name="timeout">请求超时时间</param>
        /// <param name="requestMethod">请求方法</param>
        /// <returns>请求结果</returns>
        public static string GetHttpRequestResult(string requestUrl, int timeout, SendMethod requestMethod, string codingName)
        {
            return GetRequestResult(requestUrl, timeout, requestMethod, codingName, "", "");
        }


        /// <summary>
        /// 数组冒泡排序
        /// </summary>
        /// <param name="r">要排序的数组</param>
        /// <returns>排过序的数组</returns>
        public static string[] BubbleSort(string[] r)
        {
            /// <summary>
            /// 冒泡排序法
            /// </summary>
            int i, j; //交换标志 
            string temp;

            bool exchange;

            for (i = 0; i < r.Length; i++) //最多做R.Length-1趟排序 
            {
                exchange = false; //本趟排序开始前，交换标志应为假

                for (j = r.Length - 2; j >= i; j--)
                {
                    if (System.String.CompareOrdinal(r[j + 1], r[j]) < 0)
                    {
                        temp = r[j + 1];
                        r[j + 1] = r[j];
                        r[j] = temp;

                        exchange = true; //发生了交换，故将交换标志置为真 
                    }
                }

                if (!exchange) //本趟排序未发生交换，提前终止算法 
                {
                    break;
                }

            }
            return r;
        }

        /// <summary>
        /// 14位字串转换为时间
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime ConvertToDate(string date)
        {
            if (string.IsNullOrEmpty(date))
                return DateTime.MinValue;
            StringBuilder sbdate = new StringBuilder(date);
            sbdate.Insert(4, "-");
            sbdate.Insert(7, "-");
            sbdate.Insert(10, " ");
            sbdate.Insert(13, ":");
            sbdate.Insert(16, ":");

            return Convert.ToDateTime(sbdate.ToString());
        }
    }
}
