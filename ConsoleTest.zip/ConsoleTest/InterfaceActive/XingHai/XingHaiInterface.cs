﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.CodeDom.Compiler;

namespace InterfaceActive.XingHai
{
    [ServiceContract]
    public interface IXinghai
    {
        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Hotel_List", ReplyAction = "http://tempuri.org/ixinghai/Get_Hotel_ListResponse")]
        string Get_Hotel_List(string CustomerID, string SignStr, string LastAccessDate);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Hotel_Info", ReplyAction = "http://tempuri.org/ixinghai/Get_Hotel_InfoResponse")]
        string Get_Hotel_Info(string CustomerID, string SignStr, int HotelID);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Hotel_Price", ReplyAction = "http://tempuri.org/ixinghai/Get_Hotel_PriceResponse")]
        string Get_Hotel_Price(string CustomerID, string SignStr, int HotelID, string RoomID, string StartDate, string EndDate);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Hotel_RoomState", ReplyAction = "http://tempuri.org/ixinghai/Get_Hotel_RoomStateResponse")]
        string Get_Hotel_RoomState(string CustomerID, string SignStr, int HotelID, string RoomID, string StartDate, string EndDate);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Book_Add", ReplyAction = "http://tempuri.org/ixinghai/Book_AddResponse")]
        string Book_Add(string CustomerID, string ContactUser, string ContactName, int BookType, string BookInfo, string VeryfyStr);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Book_Modify_Hotel", ReplyAction = "http://tempuri.org/ixinghai/Book_Modify_HotelResponse")]
        string Book_Modify_Hotel(string CustomerID, string Action, byte OrderType, string OrderID, string Hotel, string VeryfyStr);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Book_Modify_Plus", ReplyAction = "http://tempuri.org/ixinghai/Book_Modify_PlusResponse")]
        string Book_Modify_Plus(string CustomerID, string xhOrderID, string AdditionalProduct, string VeryfyStr);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Book_Apply", ReplyAction = "http://tempuri.org/ixinghai/Book_ApplyResponse")]
        string Book_Apply(string CustomerID, string Action, byte OrderType, string OrderID, string ApplyContent, string VeryfyStr);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Order", ReplyAction = "http://tempuri.org/ixinghai/Get_OrderResponse")]
        string Get_Order(string CustomerID, string SignStr, byte OrderType, string OrderID);

        [OperationContract(Action = "http://tempuri.org/ixinghai/Get_Order_List", ReplyAction = "http://tempuri.org/ixinghai/Get_Order_ListResponse")]
        string Get_Order_List(string CustomerID, string SignStr, byte DateType, string StartDate, string EndDate, System.Nullable<int> page);
    }
}
