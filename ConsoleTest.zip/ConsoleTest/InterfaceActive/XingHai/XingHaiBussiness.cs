﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Better.Infrastructures.Log;

namespace InterfaceActive.XingHai
{
    public class XingHaiBussiness
    {
        private string custormerId;

        private string key;

        private string sign;

        private XingHaiHelper helper;

        public XingHaiBussiness(string custormerId, string key)
        {
            this.custormerId = custormerId;
            this.key = key;

            this.sign = InterfaceUtility.GetMD5(this.custormerId + this.key + this.custormerId, "utf-8");

            this.sign = this.sign.Substring(8, 16);

            helper = new XingHaiHelper();
        }

        public string GetHotelList(string lastAccessDate)
        {
            TrackIdManager.GetInstance("test");

            return helper.Get_Hotel_List(this.custormerId, this.sign, lastAccessDate);
        }

        public string GetHotelInfo(int hotelId)
        {
            TrackIdManager.GetInstance("test");
            return helper.Get_Hotel_Info(this.custormerId, this.sign, hotelId);
        }

        public string GetHotelPrice(int hotelId, string roomId, string startDate, string endDate)
        {
            TrackIdManager.GetInstance("test");
            return helper.Get_Hotel_Price(this.custormerId, this.sign, hotelId, roomId, startDate, endDate);
        }

        public string GetHotelRoomState(int hotelID, string roomID, string startDate, string endDate)
        {
            return helper.Get_Hotel_RoomState(this.custormerId, this.sign, hotelID, roomID, startDate, endDate);
        }
    }
}
