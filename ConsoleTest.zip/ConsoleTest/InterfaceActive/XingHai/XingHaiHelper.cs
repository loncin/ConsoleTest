﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Better.Common.WCF;
using Better.Infrastructures.Log;

namespace InterfaceActive.XingHai
{
    public class XingHaiHelper
    {
        /// <summary>
        /// 日志组件业务对象
        /// </summary>
        private static ILog logBus = LogManager.GetLogger();

        /// <summary>
        /// 本地代理
        /// </summary>
        private static IXinghai proxy = null;

        /// <summary>
        /// endPointAddress
        /// </summary>
        private static string endPointAddress = string.Empty;

        public XingHaiHelper()
        {
            string configPath = System.IO.Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "WCFConfig\\XingHaiInterface.config");
            proxy = ServiceProxyFactory.Create<IXinghai>(configPath, "XingHaiClient");
            endPointAddress = ServiceProxyFactory.GetEndpointAddress<IXinghai>(configPath, "XingHaiClient");
        }

        public string Get_Hotel_List(string CustomerID, string SignStr, string LastAccessDate)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("CustomerID", CustomerID);
            dic.Add("SignStr", SignStr);
            dic.Add("LastAccessDate", LastAccessDate);

            try
            {
                return proxy.Get_Hotel_List(CustomerID, SignStr, LastAccessDate);
            }
            catch (AppException app)
            {
                throw app;
            }
            catch (Exception ex)
            {
                AppException app = new AppException("星海接口获取酒店列表，出错", CustomerException.SystemInnerException, ex);
                LogManager.Log.WriteException(app);
                throw app;
            }
        }

        public string Get_Hotel_Info(string CustomerID, string SignStr, int HotelID)
        {
            return proxy.Get_Hotel_Info(CustomerID, SignStr, HotelID);
        }

        public string Get_Hotel_Price(string CustomerID, string SignStr, int HotelID, string RoomID, string StartDate, string EndDate)
        {
            return proxy.Get_Hotel_Price(CustomerID, SignStr, HotelID, RoomID, StartDate, EndDate);
        }

        public string Get_Hotel_RoomState(string CustomerID, string SignStr, int HotelID, string RoomID, string StartDate, string EndDate)
        {
            return proxy.Get_Hotel_RoomState(CustomerID, SignStr, HotelID, RoomID, StartDate, EndDate);
        }

        //public string Book_Add(string CustomerID, string ContactUser, string ContactName, int BookType, string BookInfo, string VeryfyStr)
        //{
        //    return base.Channel.Book_Add(CustomerID, ContactUser, ContactName, BookType, BookInfo, VeryfyStr);
        //}

        //public string Book_Modify_Hotel(string CustomerID, string Action, byte OrderType, string OrderID, string Hotel, string VeryfyStr)
        //{
        //    return base.Channel.Book_Modify_Hotel(CustomerID, Action, OrderType, OrderID, Hotel, VeryfyStr);
        //}

        //public string Book_Modify_Plus(string CustomerID, string xhOrderID, string AdditionalProduct, string VeryfyStr)
        //{
        //    return base.Channel.Book_Modify_Plus(CustomerID, xhOrderID, AdditionalProduct, VeryfyStr);
        //}

        //public string Book_Apply(string CustomerID, string Action, byte OrderType, string OrderID, string ApplyContent, string VeryfyStr)
        //{
        //    return base.Channel.Book_Apply(CustomerID, Action, OrderType, OrderID, ApplyContent, VeryfyStr);
        //}

        //public string Get_Order(string CustomerID, string SignStr, byte OrderType, string OrderID)
        //{
        //    return base.Channel.Get_Order(CustomerID, SignStr, OrderType, OrderID);
        //}

        //public string Get_Order_List(string CustomerID, string SignStr, byte DateType, string StartDate, string EndDate, System.Nullable<int> page)
        //{
        //    return base.Channel.Get_Order_List(CustomerID, SignStr, DateType, StartDate, EndDate, page);
        //}

    }
}
