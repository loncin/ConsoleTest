﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceActive
{
    public class JieGetHotelInfo : JieTourInterface
    {
        /// <summary>
        /// 节点ID
        /// </summary>
        private string hotelIds;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="authNo"></param>
        /// <param name="hotelIds"></param>
        public JieGetHotelInfo(string userId, string authNo, string hotelIds)
            : base(userId, authNo)
        {
            this.hotelIds = hotelIds;
        }

        /// <summary>
        /// 请求参数
        /// </summary>
        protected override string RequestPara
        {
            get
            {
                return string.Format("{'Usercd':'{0}','Authno':'{1}','hotelIds':'{2}','QueryType':'hotelinfo'}", userId, authNo, hotelIds);
            }
        }
    }
}
