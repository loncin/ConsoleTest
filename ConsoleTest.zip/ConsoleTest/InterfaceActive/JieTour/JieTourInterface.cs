﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceActive
{
    public abstract class JieTourInterface
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        protected string userId;

        /// <summary>
        /// 授权码
        /// </summary>
        protected string authNo;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="userId">用户编号</param>
        /// <param name="authNo">安全码</param>
        public JieTourInterface(string userId, string authNo)
        {
            this.userId = userId;
            this.authNo = authNo;
        }

        /// <summary>
        /// 请求地址
        /// </summary>
        protected string RequestAddr
        {
            get { return "http://chstravel.com:30000/commonQueryServlet"; }
        }

        /// <summary>
        /// 请求参数
        /// </summary>
        protected abstract string RequestPara
        {
            get;
        }

        /// <summary>
        /// 请求URL
        /// </summary>
        protected string RequstUrl
        {
            get
            {
                return RequestAddr + "?" + RequestPara;
            }
        }

        /// <summary>
        /// 请求是否成功
        /// </summary>
        public bool IsSuccess
        {
            get;
            set;
        }

        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrDescription
        {
            get;
            set;
        }

        public string Send()
        {
            try
            {
                IsSuccess = true;
                return InterfaceUtility.GetHttpRequestResult(RequstUrl, 120000, SendMethod.POST, "utf-8");
            }
            catch (Exception ex)
            {
                IsSuccess = false;
                ErrDescription = "接口异常:" + ex.Message;
                return string.Empty;
            }
        }
    }
}
