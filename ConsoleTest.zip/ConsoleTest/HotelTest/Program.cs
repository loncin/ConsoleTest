﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Better517Na.HotelBookIntegration.Helper;
using Better517Na.HotelBookIntegration.Contract;
using System.Diagnostics;
using System.Threading;
using System.Collections;

namespace HotelTest
{
    class Program
    {
        static void Main(string[] args)
        {
            MessagePipe.WriteLogEvent += delegate(string msg)
            {
                System.Diagnostics.Trace.WriteLine(msg);
                System.Diagnostics.Trace.Flush();

                Console.WriteLine(msg);
                Console.WriteLine();
            };

            MessagePipe.RaiseEvent("………………测试开始执行………………");
            for (int i = 0; i < 1; i++)
            {
                Thread4CallService threadCallService = new Thread4CallService();
                Thread thread = new Thread(threadCallService.CallService);
                thread.IsBackground = true;
                thread.Name = "thread_" + i;
                thread.Start();
            }
           
            Console.ReadKey();
        }
    }
}
