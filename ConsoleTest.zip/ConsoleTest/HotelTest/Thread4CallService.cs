﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Better517Na.HotelBookIntegration.Helper;
using Better517Na.HotelBookIntegration.Contract;
using System.Diagnostics;
using System.Threading;

namespace HotelTest
{
    public class Thread4CallService
    {
        public void CallService()
        {
            for (int i = 0; i < 10; i++)
            {
                Stopwatch stop = new Stopwatch();
                stop.Start();

                // 酒店价格查询测试
                string providerID = "58338";
                string roomID = "100110110001001381";
                int broadNet = 0;
                int bedType = 0;
                int breakfastCount = 8;
                DateTime changeBegin = DateTime.Now;
                DateTime changeEnd = DateTime.Now.AddDays(1);

                HotelBookIntegrationHelper integrationHelper = new HotelBookIntegrationHelper();
                List<MPolicyAndStockInfo> policyStock = integrationHelper.GetPolicyAndStockInfo(providerID, roomID, broadNet, bedType, breakfastCount, changeBegin, changeEnd);

                stop.Stop();

                string strMsg = string.Format("当前第{0}次执行耗时为:{1}毫秒", i + 1, stop.Elapsed.TotalMilliseconds);
                MessagePipe.RaiseEvent(strMsg);

                Thread.Sleep(1000);
                MessagePipe.RaiseEvent("休眠1000毫秒");
            }
        }
    }
}
