﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HotelTest
{
    public class MessagePipe
    {
        public delegate void WriteLogHandler(string msg);

        public static event WriteLogHandler WriteLogEvent;

        public static void RaiseEvent(string msg)
        {
            if (WriteLogEvent != null)
            {
                WriteLogEvent(msg);
            }
        }
    }
}
