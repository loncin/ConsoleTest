﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Loncin.Test.Contract;

namespace Loncin.Test.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ChannelFactory<ICalcContract> factory = new ChannelFactory<ICalcContract>("CalcServiceEndPoint"))
            {
                ICalcContract proxy = factory.CreateChannel();
                using (proxy as IDisposable)
                {
                    Console.WriteLine(proxy.Add(2, 3));
                }
            }

            Console.ReadKey();
        }
    }
}
