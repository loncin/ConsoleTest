﻿var UploadFile
function btnUpload() {
    $("#hidFormUpload").remove("input[name='hidNameFile']");

    $("#hidFormUpload").append($("#userFile"));

    $("#hidFormUpload").submit();
}

$(function() {
    // 用户上传插件
    var dvUser = $("#dvUpload");
    var userFile = $("<input type='file' id='userFile' name='hidNameFile'/>");
    var btnUpload = $("<input type ='button' id='btnload' value='上传' onclick='btnUpload();'/>");

    dvUser.append(userFile);
    dvUser.append(btnUpload);

    // 隐藏的上传插件
    var dvFrame = $("<div></div>");
    dvFrame.css("display", "none");
    
    var frame = $("<iframe></iframe>");
    frame.attr("name", "frameUpload");
    dvFrame.append(frame);

    var form = $("<form id='hidFormUpload' target='frameUpload' method='post' enctype='multipart/form-data' action=''></form>");
    var hidFile = $("<input type='file' id='hidFile' name = 'hidNameFile'/>");

    form.append(hidFile);
    dvFrame.append(form);

    $("body").append(dvFrame);
});