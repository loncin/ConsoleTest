﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Xml;
using System.Threading;
using System.Collections.Specialized;

namespace WebTest
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.Load(AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "Config.xml");
            //XmlNode xmlNode = xmlDoc.DocumentElement.SelectSingleNode("/GlobalConfig/Config[@Name='FileLock']");
            //if (xmlNode != null)
            //{
            //    XmlElement xe = xmlNode as XmlElement;
            //    string value = xe.GetAttribute("Value");
            //    xe.SetAttribute("Value", "close");
            //}

            //xmlDoc.Save(AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "Config.xml");

            //Response.Redirect("~/Test1.aspx");
            //Response.Redirect("~/Test2.aspx");

            //Session["hello"] = "test";
            //Thread thread = new Thread(Test);

            //thread.Start();

            //HttpRuntime.Cache.Remove("kk");

            //DateTime dtNow = DateTime.Now;

            //DateTime dtAdd = dtNow.AddMonths(0);
        }

        public void Test()
        {
            string str = Session["hello"].ToString();

            NameValueCollection collection = HttpContext.Current.Request.QueryString;

            return;
        }
    }
}


