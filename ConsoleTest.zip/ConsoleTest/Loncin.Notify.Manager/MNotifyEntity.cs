﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Notify.Manager
{
    /// <summary>
    /// 通知实体
    /// </summary>
    public class MNotifyEntity
    {
        /// <summary>
        /// 实体ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 业务类型(如出票)
        /// </summary>
        public string BusiType { get; set; }

        /// <summary>
        /// 业务ID(如订单ID)
        /// </summary>
        public string BusiID { get; set; }

        /// <summary>
        /// 通知是否推送
        /// </summary>
        public bool IsPublish { get; set; }

        /// <summary>
        /// 通知产生时间
        /// </summary>
        public DateTime AddTime { get; set; }
    }
}
