﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Test.Model
{
    public class MHotelOrderB
    {
        public MHotelOrderB()
        {
            this.dicPara = new Dictionary<int, string>();
            this.dicPara.Add(0, "A");
            this.dicPara.Add(1, "B");
            this.dicPara.Add(2, "C");
        }

        private Dictionary<int, string> dicPara;

        private int handlingFee = 10;

        public string OrderId { get; set; }

        public string HotelID { get; set; }

        public string HotelName { get; set; }

        public decimal TotalFee { get; set; }

        public List<MHotelRoomA> Rooms { get; set; }

        public int YfMoney { get; set; }

        public string this[int index]
        {
            get { return this.dicPara[index]; }
            set { this.dicPara[index] = value; }
        }

        public int HandlingFee
        {
            get
            {
                return this.handlingFee;
            }
        }
    }
}
