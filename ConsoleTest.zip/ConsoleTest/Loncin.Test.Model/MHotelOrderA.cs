﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Test.Model
{
    public class MHotelOrderA
    {
        public MHotelOrderA()
        {
            this.dicPara = new Dictionary<int, string>();
            this.dicPara.Add(0, "X");
            this.dicPara.Add(1, "Y");
            this.dicPara.Add(2, "Z");
        }

        private Dictionary<int, string> dicPara;

        private int handlingFee = 11;

        public string OrderId { get; set; }

        public string HotelID { get; set; }

        public string HotelName { get; set; }

        public decimal TotalFee { get; set; }

        public List<MHotelRoomA> Rooms { get; set; }

        public decimal YfMoney { get; set; }

        public string this[int index]
        {
            get { return this.dicPara[index]; }
            set { this.dicPara[index] = value; }
        }

        public int HandlingFee
        {
            get
            {
                return this.handlingFee;
            }
        }
    }
}
