﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Test.Model
{
    public class MHotelRoomA
    {
        public string KyeID { get; set; }

        public int RoomImdex { get; set; }

        public DateTime CheckInDate { get; set; }

    }
}
