﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loncin.Test.Model
{
    public class MSerializer
    {
        public string ID { get; set; }

        public DateTime Day { get; set; }
    }
}
